package com.example.proyectoIntegradorSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoIntegradorSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
