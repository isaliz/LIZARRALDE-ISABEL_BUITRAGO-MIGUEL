package com.example.proyectoIntegradorSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoIntegradorSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoIntegradorSpringApplication.class, args);
	}

}
